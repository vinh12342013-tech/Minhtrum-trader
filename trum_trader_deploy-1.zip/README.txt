TRUM TRADER - BAN SAN SANG DEPLOY LEN RENDER

Can co:
- app.py
- requirements.txt
- static/background.jpg

Cac gia tri khi tao Render Web Service:
Build Command: pip install -r requirements.txt
Start Command: gunicorn app:app
Instance Type: Free

Cach dang tai:
1. Tao repository moi tren GitHub.
2. Upload 3 muc noi dung nay len repository (app.py, requirements.txt, thu muc static co background.jpg).
3. Tren Render, tao New > Web Service, ket noi repository GitHub.
4. Chon Build Command va Start Command nhu tren, chon Free, roi Create Web Service.
5. Sau khi deploy thanh cong, Render hien URL onrender.com cua website.
