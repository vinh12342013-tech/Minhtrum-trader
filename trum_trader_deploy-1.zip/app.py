from flask import Flask, render_template_string

app = Flask(__name__)

HTML = r"""
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Trùm Trader</title>
<style>
  * { box-sizing: border-box; }
  html, body { margin: 0; min-height: 100%; }
  body {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    font-family: Arial, Helvetica, sans-serif;
    background:
      linear-gradient(180deg, rgba(0,0,0,.12), rgba(0,0,0,.35)),
      url("/static/background.jpg") center center / cover no-repeat fixed;
  }
  .shade {
    position: fixed; inset: 0;
    background: radial-gradient(ellipse at center, transparent 20%, rgba(0,0,0,.35) 100%);
    pointer-events: none;
  }
  .content {
    position: relative;
    z-index: 1;
    width: min(94vw, 1000px);
    text-align: center;
    padding: 28px 18px;
  }
  .label {
    display: inline-block;
    margin-bottom: 18px;
    padding: 9px 18px;
    border: 1px solid rgba(255,255,255,.8);
    border-radius: 999px;
    color: white;
    background: rgba(0,0,0,.55);
    letter-spacing: 5px;
    font-size: clamp(11px, 2vw, 15px);
    box-shadow: 0 0 14px #00eaff, 0 0 28px #ff00e6;
  }
  h1 {
    margin: 0;
    font-size: clamp(42px, 11vw, 112px);
    line-height: 1.05;
    font-weight: 1000;
    letter-spacing: -2px;
    background: linear-gradient(90deg,
      #ff1744, #ff9100, #ffee00, #00ff7f,
      #00e5ff, #3d5afe, #e040fb, #ff1744);
    background-size: 400% 100%;
    color: transparent;
    -webkit-background-clip: text;
    background-clip: text;
    animation: rainbow 3s linear infinite, glow 1.4s ease-in-out infinite alternate;
    filter: drop-shadow(0 0 5px rgba(255,255,255,.9))
            drop-shadow(0 0 15px rgba(255,0,220,.9))
            drop-shadow(0 0 32px rgba(0,229,255,.8));
    -webkit-text-stroke: 1px rgba(255,255,255,.2);
  }
  .underline {
    height: 5px;
    width: min(72vw, 520px);
    margin: 24px auto 0;
    border-radius: 999px;
    background: linear-gradient(90deg, #ff1744, #ffea00, #00ff7f, #00e5ff, #e040fb);
    background-size: 250% 100%;
    animation: rainbow 2s linear infinite;
    box-shadow: 0 0 12px #00e5ff, 0 0 25px #ff00e6;
  }
  .caption {
    margin-top: 18px;
    color: white;
    font-size: clamp(12px, 2.5vw, 18px);
    font-weight: bold;
    letter-spacing: 3px;
    text-shadow: 0 0 8px #00e5ff, 0 0 16px #ff00e6;
  }
  @keyframes rainbow { to { background-position: 400% 0; } }
  @keyframes glow {
    from { filter: drop-shadow(0 0 4px #fff) drop-shadow(0 0 12px #ff00e6); }
    to { filter: drop-shadow(0 0 9px #fff) drop-shadow(0 0 28px #00e5ff) drop-shadow(0 0 42px #ff00e6); }
  }
  @media (prefers-reduced-motion: reduce) {
    *, *::before, *::after { animation: none !important; }
  }
</style>
</head>
<body>
  <div class="shade"></div>
  <main class="content">
    <div class="label">⚡ RGB LEGEND ⚡</div>
    <h1>TRÙM TRADER</h1>
    <div class="underline"></div>
    <div class="caption">✨ LOÈ LOẸT • BẢY SẮC CẦU VỒNG ✨</div>
  </main>
</body>
</html>
"""

@app.route("/")
def home():
    return render_template_string(HTML)

if __name__ == "__main__":
    print("Mo trinh duyet tai http://127.0.0.1:5000")
    app.run(host="0.0.0.0", port=5000, debug=False)
